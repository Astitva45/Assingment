const video = document.getElementById("customVideo");
const playButton = document.getElementById("customPlayButton");

playButton.addEventListener("click", () => {
  if (video.paused) {
    video.play();
    playButton.style.display = "none";
  } else {
    video.pause();
    playButton.style.display = "flex";
  }
});

video.addEventListener("pause", () => {
  playButton.style.display = "flex";
});

video.addEventListener("play", () => {
  playButton.style.display = "none";
});

const track = document.querySelector(".testimonial-track");
const items = document.querySelectorAll(".testimonial-item");
const dotsContainer = document.getElementById("testimonialDots");
let currentIndex = 0, interval;

items.forEach((_, i) => {
  const dot = document.createElement("div");
  dot.className = `testimonial-dot${i === 0 ? " active" : ""}`;
  dot.addEventListener("click", () => goToSlide(i));
  dotsContainer.appendChild(dot);
});

const dots = document.querySelectorAll(".testimonial-dot");

function goToSlide(index) {
  currentIndex = index;
  track.style.transform = `translateX(-${index * 100}%)`;
  dots.forEach((d, i) => d.classList.toggle("active", i === index));
  resetInterval();
}

function startAutoSlide() {
  interval = setInterval(() => goToSlide((currentIndex + 1) % items.length), 5000);
}

function resetInterval() {
  clearInterval(interval);
  startAutoSlide();
}

startAutoSlide();
